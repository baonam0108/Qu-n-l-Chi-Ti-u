package com.example.moneylover.ui.khoanchi.fragment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.moneylover.DAO.LoaichiDAO;
import com.example.moneylover.R;
import com.example.moneylover.adapter.LoaiChiAdapter;
import com.example.moneylover.moder.LoaiChi;

import java.util.List;

public class ThemLoaiChiActivity extends AppCompatActivity {

    private EditText edtMa,edtTen;
    private Button btnLuu;
    private LoaichiDAO loaichiDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_them_loai_chi);

        loaichiDAO = new LoaichiDAO(ThemLoaiChiActivity.this);

        edtMa = findViewById(R.id.edtMaLoaiChi);
        edtTen = findViewById(R.id.edtTenLoaiChi);
        btnLuu = findViewById(R.id.btnLuu);




        btnLuu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String maLC = edtMa.getText().toString();
                String tenLC = edtTen.getText().toString();

                LoaiChi loaiChi = new LoaiChi(maLC,tenLC);

                boolean result = loaichiDAO.insertLoaiChi(loaiChi);
                if(result){
                    Toast.makeText(ThemLoaiChiActivity.this,"Chen thanh cong", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(ThemLoaiChiActivity.this,"Chen that bai", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
