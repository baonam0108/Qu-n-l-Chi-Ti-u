package com.example.moneylover.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.moneylover.database.Database;
import com.example.moneylover.moder.LoaiChi;
import com.example.moneylover.moder.LoaiThu;

import java.util.ArrayList;
import java.util.List;

public class LoaiThuDAO {
    private SQLiteDatabase sqliteDB;
    private Database dbHelper;


    public LoaiThuDAO(Context context){
        dbHelper = new Database(context);
        sqliteDB = dbHelper.getWritableDatabase();
    }

    public long insertLoaiThu(LoaiThu loaiThu){

            ContentValues values = new ContentValues();

            values.put(dbHelper.Col_ID, loaiThu.getMaLoaiThu());
            values.put(dbHelper.Col_TEN, loaiThu.getTenLoaiThu());

            long numInsert = sqliteDB.insert(dbHelper.TABLE_NAME,null,values);
            sqliteDB.close();
       return numInsert;
    }

    public List<LoaiThu> getALLLoaiThu(){
        List<LoaiThu> loaiThuList = new ArrayList<>();
        sqliteDB = dbHelper.getReadableDatabase();

        String truyVan = "SELECT * FROM " + dbHelper.TABLE_NAME;
        Cursor cursor = sqliteDB.rawQuery(truyVan,null);

        if (cursor.getCount()>0){
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){

                String ma = cursor.getString(cursor.getColumnIndex(dbHelper.Col_ID));
                String ten = cursor.getString(cursor.getColumnIndex(dbHelper.Col_TEN));

                LoaiThu loaiThu= new LoaiThu();

                loaiThu.setMaLoaiThu(ma);
                loaiThu.setTenLoaiThu(ten);

                loaiThuList.add(loaiThu);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return loaiThuList;
    }

    public long delLoaiThu(LoaiThu loaiThu){

        long resutl = sqliteDB.delete(dbHelper.TABLE_NAME, dbHelper.Col_ID+"=?",new String[]{loaiThu.maLoaiThu});

        sqliteDB.close();
        return resutl;
    }
}