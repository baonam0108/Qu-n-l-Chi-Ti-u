package com.example.moneylover.moder;

import java.util.Date;

public class KhoanChi {
    public  String maKhoanChi,soTien,moTa,loaiChi;
    public String ngayChi;


    public String getMaKhoanChi() {
        return maKhoanChi;
    }

    public void setMaKhoanChi(String maKhoanChi) {
        this.maKhoanChi = maKhoanChi;
    }

    public String getSoTien() {
        return soTien;
    }

    public void setSoTien(String soTien) {
        this.soTien = soTien;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getLoaiChi() {
        return loaiChi;
    }

    public void setLoaiChi(String loaiChi) {
        this.loaiChi = loaiChi;
    }

    public String getNgayChi() {
        return ngayChi;
    }

    public void setNgayChi(String ngayChi) {
        this.ngayChi = ngayChi;
    }

    @Override
    public String toString() {
        return getLoaiChi();
    }
}
