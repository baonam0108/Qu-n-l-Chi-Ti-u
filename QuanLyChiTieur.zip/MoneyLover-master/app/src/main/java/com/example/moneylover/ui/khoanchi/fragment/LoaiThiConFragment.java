package com.example.moneylover.ui.khoanchi.fragment;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.moneylover.DAO.LoaichiDAO;
import com.example.moneylover.R;

import com.example.moneylover.adapter.LoaiChiAdapter;
import com.example.moneylover.moder.LoaiChi;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class LoaiThiConFragment extends Fragment {

    private ListView lvLoaiChi;
    private LoaichiDAO loaichiDAO;
    private LoaiChiAdapter loaiChiAdapter;
    private List<LoaiChi> loaiChiList;

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.loanthifragmet,container,false);

        loaichiDAO = new LoaichiDAO(getActivity());
        lvLoaiChi = view.findViewById(R.id.lvLoaiChi);
        hienThi();

        //Nút thêm
        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                Intent intent = new Intent(getActivity(),ThemLoaiChiActivity.class);
                startActivity(intent);
            }
        });
        return view;
    }

    public void hienThi(){
        loaiChiList = loaichiDAO.getALLLoaiChi();
        loaiChiAdapter = new LoaiChiAdapter(getActivity(),loaiChiList);
        lvLoaiChi.setAdapter(loaiChiAdapter);
        loaiChiAdapter.notifyDataSetChanged();
    }

}
