package com.example.moneylover.ui.thongke;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.moneylover.DAO.KhoanChiDAO;
import com.example.moneylover.R;
import com.example.moneylover.moder.KhoanChi;

import java.util.ArrayList;
import java.util.List;

public class ThongkeFragment extends Fragment {

    private ThongKeViewModel toolsViewModel;
    private int ab;
    private KhoanChiDAO khoanChiDAO;
    private List<KhoanChi> khoanChiList;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        toolsViewModel =
                ViewModelProviders.of(this).get(ThongKeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_tools, container, false);

        TextView tongChi = root.findViewById(R.id.tongchi);
        TextView tongThu= root.findViewById(R.id.tongthu);

        khoanChiDAO = new KhoanChiDAO(getActivity());
        khoanChiList = new ArrayList<>();
        khoanChiList = khoanChiDAO.getAllKhoanChi();

        int tong = 0;
        for (KhoanChi khoanChi: khoanChiList){
            tong += (Integer.parseInt(khoanChi.getSoTien()));
        }
       int ab = tong;
        KhoanChi khoanChi = new KhoanChi();
        khoanChi.setSoTien(String.valueOf(ab));
        String a = khoanChi.getSoTien();

        tongChi.setText(a + " VNĐ");
        tongThu.setText(a + " VNĐ");
        return root;
    }
}