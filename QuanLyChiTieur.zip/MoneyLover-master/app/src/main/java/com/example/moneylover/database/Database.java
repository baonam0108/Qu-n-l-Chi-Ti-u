package com.example.moneylover.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    public Database(Context context) {
        super(context, "dbChiTieu", null, 7);
    }

    //Bảng LoaiThu
    public static final String TABLE_NAME = "sinhvien";
    public static final String Col_ID = "name";
    public static final String Col_TEN= "class";

    //Bảng Khoản Chi
    public static final String TABLE_KhoanChi = "KhoanChi";
    public static final String Col_IDKhoanChi = "IDKhoanChi";
    public static final String Col_LoaiChi = "loaichi";
    public static final String Col_SoTien= "SoTien";
    public static final String Col_NgayChi= "NgayChi";
    public static final String Col_moTa= "moTa";


    //Bang khoan thu
    public static final String TABLE_Khoanthu = "Khoanthu";
    public static final String Col_IDKhoanthu = "IDKhoanthu";
    public static final String Col_Loaithu = "loaithu";
    public static final String Col_SoTienthu= "SoTien";
    public static final String Col_Ngaythu= "Ngaythu";
    public static final String Col_moTaloaithu= "moTa";

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        //Khởi tạo Bảng loại chi
        String createTableLoaiChi = "create table LoaiChi(maLC text primary key, tenLC text)";
        sqLiteDatabase.execSQL(createTableLoaiChi);
        //Khởi tạo Bảng loại Thu
        String createTableLoaiThu = "CREATE TABLE " +TABLE_NAME +"("+Col_ID+" VARCHAR PRIMARY KEY,"+Col_TEN+" VARCHAR )";
        sqLiteDatabase.execSQL(createTableLoaiThu);
        //Khởi tạo bảng khoản chi
        String createTableKhoanChi = "CREATE TABLE " +TABLE_KhoanChi +"("+Col_IDKhoanChi+" VARCHAR PRIMARY KEY,"+Col_SoTien+" VARCHAR,"+Col_LoaiChi +" VARCHAR, "+ Col_moTa +" VARCHAR,"+Col_NgayChi +" DATE )";
        sqLiteDatabase.execSQL(createTableKhoanChi);
        //Khởi tạo bảng khoản thu
        String createTableKhoanThu = "CREATE TABLE " + TABLE_Khoanthu +"("+ Col_IDKhoanthu+" VARCHAR PRIMARY KEY,"+ Col_SoTienthu+" VARCHAR,"+ Col_Loaithu +"VARCHAR," + Col_moTaloaithu + "VARCHAR,"+ Col_Ngaythu+"DATE)";
        sqLiteDatabase.execSQL(createTableKhoanThu);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("drop table if exists LoaiChi");
        sqLiteDatabase.execSQL("drop table if exists " + TABLE_NAME);
        sqLiteDatabase.execSQL("drop table if exists " + TABLE_KhoanChi);
        onCreate(sqLiteDatabase);
    }
}
