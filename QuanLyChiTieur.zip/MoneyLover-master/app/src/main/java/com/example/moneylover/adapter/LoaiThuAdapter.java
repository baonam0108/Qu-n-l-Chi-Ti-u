package com.example.moneylover.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.moneylover.DAO.LoaiThuDAO;
import com.example.moneylover.R;
import com.example.moneylover.moder.LoaiThu;

import java.util.List;

public class LoaiThuAdapter extends BaseAdapter {

    private LinearLayout linearLayout;
    private Context context;
    private List<LoaiThu> loaiThuList;
    private LoaiThuDAO loaiThuDAO;

    public LoaiThuAdapter(Context context, List<LoaiThu> loaiThuList) {
        this.context = context;
        this.loaiThuList = loaiThuList;
    }

    @Override
    public int getCount() {
        return loaiThuList.size();
    }

    @Override
    public Object getItem(int position) {
        return loaiThuList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.loaithu,parent,false);

        TextView tvMa = view.findViewById(R.id.tvMa);
        TextView tvTen = view.findViewById(R.id.tvTen);

        final LoaiThu loaiThu = (LoaiThu) getItem(position);

        tvMa.setText(loaiThu.maLoaiThu);
        tvTen.setText(loaiThu.tenLoaiThu);

        //xoa

        linearLayout = view.findViewById(R.id.lineLoaiThu);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loaiThuDAO = new LoaiThuDAO(context);
                LoaiThu loaiThu1= loaiThuList.get(position);

                loaiThuDAO.delLoaiThu(loaiThu1);
                loaiThuList.remove(loaiThu1);
                notifyDataSetChanged();
            }
        });
        return view;
    }
}
