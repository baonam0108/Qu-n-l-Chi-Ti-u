package com.example.moneylover.moder;

public class LoaiThu {
    public String maLoaiThu,tenLoaiThu;



    public String getMaLoaiThu() {
        return maLoaiThu;
    }

    public void setMaLoaiThu(String maLoaiThu) {
        this.maLoaiThu = maLoaiThu;
    }

    public String getTenLoaiThu() {
        return tenLoaiThu;
    }

    public void setTenLoaiThu(String tenLoaiThu) {
        this.tenLoaiThu = tenLoaiThu;
    }
}
