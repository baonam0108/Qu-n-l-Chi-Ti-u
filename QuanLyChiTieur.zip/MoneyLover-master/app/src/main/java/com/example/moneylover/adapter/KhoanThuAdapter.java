package com.example.moneylover.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.moneylover.DAO.KhoanChiDAO;
import com.example.moneylover.DAO.KhoanThuDAO;
import com.example.moneylover.DAO.LoaiThuDAO;
import com.example.moneylover.DAO.LoaichiDAO;
import com.example.moneylover.moder.KhoanChi;
import com.example.moneylover.moder.KhoanThu;
import com.example.moneylover.moder.LoaiChi;
import com.example.moneylover.moder.LoaiThu;

import java.text.SimpleDateFormat;
import java.util.List;

public class KhoanThuAdapter extends BaseAdapter {
    private Context context;
    private List<KhoanThu> khoanThuList;
    private List<LoaiThu> loaiThuList;
    private KhoanThuDAO khoanThuDAO;
    private LoaiThuDAO loaiThuDAO;

    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    public KhoanThuAdapter(Context context, List<KhoanThu> khoanChiList) {
        this.context = context;
        this.khoanThuList = khoanThuList;
    }
    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return null;
    }
}
